CSC281 - 10/5/16
Mad Jack Text Based Adventure
The Legendary Developers : Andy�Bae, Drew Schweikert, Nathanael Lane

 To play Mad Jack, try to survive for the rest of WWII by picking the correct choices. 
Although you can usually take multiple paths, sometimes, surviving requires very 
specific actions and links. Good luck, and may the spirit of Jack Churchill guide your path! 
 Click red links to go to the next page that was based on the link/choice you chose.
 Links that have been selected will turn blue for easier navigation to the right solution.

 
